#pragma once
#include "Scene.h"

class Scene1 : public Scene
{
public:
	void init() override;
};