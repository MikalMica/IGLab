#pragma once
#include "Scene.h"

class Scene4 : public Scene
{
public:
	void init() override;
};