#pragma once
#include "Scene.h"

class Scene2 : public Scene
{
	public:
		void init() override;
	};

