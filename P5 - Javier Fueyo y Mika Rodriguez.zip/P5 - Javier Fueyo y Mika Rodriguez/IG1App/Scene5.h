#pragma once
#include "Scene.h"

class Scene5 : public Scene
{
public:
	void init() override;
};
