#pragma once
#include "Scene.h"

class Scene7 : public Scene
{
public:
	void init() override;
};
