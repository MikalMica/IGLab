#pragma once
#include "Scene.h"

class Scene10 : public Scene
{
public:
	void init() override;
};
